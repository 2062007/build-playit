Usage:
  chmod +x playit
  ./playit
